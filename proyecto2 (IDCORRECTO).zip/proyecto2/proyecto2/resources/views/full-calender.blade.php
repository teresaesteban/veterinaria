<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('CALENDARIO') }}
        </h2>
    </x-slot>
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Calendario</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,600&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" />
    </head>
    <header class="py-5">
        <!-- Header content here -->
    </header>
    <body id="page-top">
        <section id="calendar-features">
            <!-- Calendar features section content here -->
        </section>
        <br>
        <h1 class="display-5 lh-6 mb-3 text-center">Calendario clínica veterinaria</h1>
        <div class="d-flex justify-content-center">
            <img src="images/title.jpg" alt="Calendario" style="width: 10%;" />
        </div>
        <div id="ir"></div>
        <div id="calendar"></div>
        <br>
        <section class="call-to-action text-white text-center" id="contact">
            <!-- Contact form section content here -->
        </section>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
        <script>
            $(document).ready(function () {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                var calendar = $('#calendar').fullCalendar({
                    editable: true,
                    header: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'month,agendaWeek,agendaDay'
                    },
                    events: @json($events),
                    selectable: true,
                    selectHelper: true,
                    select: function (start, end, allDay) {
                        var title = prompt('Motivo general de tu cita:');

                        if (title) {
                            var start = $.fullCalendar.formatDate(start, 'Y-MM-DD HH:mm:ss');
                            var end = $.fullCalendar.formatDate(end, 'Y-MM-DD HH:mm:ss');

                            $.ajax({
                                url: "/full-calender/action",
                                type: "POST",
                                data: {
                                    title: title,
                                    start: start,
                                    end: end,
                                    type: 'add'
                                },
                                success: function (data) {
                                    calendar.fullCalendar('refetchEvents');
                                    alert("Cita creada exitosamente");
                                },

                            })
                        }
                    },
                    eventResize: function (event, delta) {
                        var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                        var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                        var title = event.title;
                        var id = event.id;

                        $.ajax({
                            url: "/full-calender/action",
                            type: "POST",
                            data: {
                                title: title,
                                start: start,
                                end: end,
                                id: id,
                                type: 'update'
                            },
                            success: function (response) {
                                calendar.fullCalendar('refetchEvents');
                                alert("Cita actualizada exitosamente");
                            }
                        })
                    },
                    eventDrop: function (event, delta) {
                        var start = $.fullCalendar.formatDate(event.start, 'Y-MM-DD HH:mm:ss');
                        var end = $.fullCalendar.formatDate(event.end, 'Y-MM-DD HH:mm:ss');
                        var title = event.title;
                        var id = event.id;

                        $.ajax({
                            url: "/full-calender/action",
                            type: "POST",
                            data: {
                                title: title,
                                start: start,
                                end: end,
                                id: id,
                                type: 'update'
                            },
                            success: function (response) {
                                calendar.fullCalendar('refetchEvents');
                                alert("Cita actualizada exitosamente");
                            }
                        })
                    },

                    eventClick: function (event) {
                        if (confirm("¿Estás seguro de querer borrarla?")) {
                            var id = event.id;

                            $.ajax({
                                url: "/full-calender/action",
                                type: "POST",
                                data: {
                                    id: id,
                                    type: "delete"
                                },
                                success: function (response) {
                                    calendar.fullCalendar('refetchEvents');
                                    alert("Cita borrada exitosamente");
                                },
                                error: function (xhr, status, error) {
                    if (xhr.status == 403) {
                        alert("No tienes permiso para borrar este evento.");
                    } else {
                        alert("Error: " + xhr.responseText);
                    }
                }

                            })
                        }
                    }
                });
            });
        </script>
    </body>
</x-app-layout>

@include('registro.footer')
