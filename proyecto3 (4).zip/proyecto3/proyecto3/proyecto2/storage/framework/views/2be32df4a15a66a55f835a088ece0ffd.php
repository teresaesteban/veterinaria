<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-white leading-tight">
            <?php echo e(__('HISTORIAL CLÍNICO')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-white">
                    <?php if(session('citaGuardada')): ?>
                        <div class="bg-green-500 text-white p-4 mb-4">
                            <?php echo e(session('citaGuardada')); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Botón para mostrar el formulario de agregar cita -->
                    <button id="mostrarFormulario" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded">
                        <?php echo e(__('Agregar Cita')); ?>

                    </button>

                    <!-- Contenedor del formulario de agregar cita -->
                    <div id="formularioCita" class="hidden mt-4">
                        <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Agregar Cita')); ?></h3>
                        <form action="<?php echo e(route('citas.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label for="fecha" class="block text-sm font-medium text-white">Fecha de la Cita:</label>
                                <input type="date" name="fecha" id="fecha" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md">
                            </div>
                            <div class="mb-4">
                                <label for="motivo" class="block text-sm font-medium text-white">Motivo de la Cita:</label>
                                <textarea name="motivo" id="motivo" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="diagnostico" class="block text-sm font-medium text-white">Diagnóstico:</label>
                                <textarea name="diagnostico" id="diagnostico" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="tratamiento" class="block text-sm font-medium text-white">Tratamiento:</label>
                                <textarea name="tratamiento" id="tratamiento" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div>
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring focus:ring-indigo-300 disabled:opacity-25 transition"><?php echo e(__('Guardar Cita')); ?></button>
                            </div>
                        </form>
                    </div>

                    <!-- Contenedor del formulario de modificar cita (inicialmente oculto) -->
                    <div id="formularioModificarCita" class="hidden mt-4">
                        <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Modificar Cita Guardada')); ?></h3>
                        <form id="formModificarCita" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-4">
                                <label for="fecha_modificar" class="block text-sm font-medium text-white">Fecha de la Cita:</label>
                                <input type="date" name="fecha_modificar" id="fecha_modificar" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md">
                            </div>
                            <div class="mb-4">
                                <label for="motivo_modificar" class="block text-sm font-medium text-white">Motivo de la Cita:</label>
                                <textarea name="motivo_modificar" id="motivo_modificar" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="diagnostico_modificar" class="block text-sm font-medium text-white">Diagnóstico:</label>
                                <textarea name="diagnostico_modificar" id="diagnostico_modificar" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="tratamiento_modificar" class="block text-sm font-medium text-white">Tratamiento:</label>
                                <textarea name="tratamiento_modificar" id="tratamiento_modificar" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md"></textarea>
                            </div>
                            <div>
                                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest bg-blue-600 hover:bg-blue-700 active:bg-blue-900 focus:outline-none focus:border-blue-900 focus:ring focus:ring-blue-300 disabled:opacity-25 transition"><?php echo e(__('Guardar Cambios')); ?></button>
                            </div>
                        </form>
                    </div>

                    <form action="<?php echo e(route('citas.index')); ?>" method="GET" class="mb-4">
                        <?php echo csrf_field(); ?>
                        <label for="mascota_id" class="block text-sm font-medium text-white">Selecciona Mascota:</label>
                        <select name="mascota_id" id="mascota_id" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-700 rounded-md">
                            <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mascota->id); ?>"><?php echo e($mascota->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="mt-2 inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring focus:ring-indigo-300 disabled:opacity-25 transition"><?php echo e(__('Mostrar Historial')); ?></button>
                    </form>

                    <div class="mt-8">
                        <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Citas Registradas')); ?></h3>
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
                            <thead class="bg-gray-700">
                                <tr>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider text-white"><?php echo e(__('Fecha')); ?></th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider text-white"><?php echo e(__('Motivo de Cita')); ?></th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider text-white"><?php echo e(__('Diagnóstico')); ?></th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider text-white"><?php echo e(__('Tratamiento')); ?></th>
                                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider text-white"><?php echo e(__('Acciones')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="bg-gray-900 ">
                                <!-- Iterar sobre cada cita -->
                                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-white"><?php echo e($cita->fecha); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-white"><?php echo e($cita->motivo); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-white"><?php echo e($cita->diagnostico); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-white"><?php echo e($cita->tratamiento); ?></div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <!-- Botón para mostrar el formulario de modificar cita -->
                                            <button onclick="mostrarModificarFormulario(<?php echo e($cita->id); ?>, '<?php echo e($cita->fecha); ?>', '<?php echo e($cita->motivo); ?>', '<?php echo e($cita->diagnostico); ?>', '<?php echo e($cita->tratamiento); ?>')" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded">
                                                <?php echo e(__('Modificar')); ?>

                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- Fin de la iteración -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Función para mostrar el formulario de modificar cita con los datos de la cita seleccionada
        window.mostrarModificarFormulario = function(id, fecha, motivo, diagnostico, tratamiento) {
            // Llenamos el formulario con los datos de la cita seleccionada
            document.getElementById('fecha_modificar').value = fecha;
            document.getElementById('motivo_modificar').value = motivo;
            document.getElementById('diagnostico_modificar').value = diagnostico;
            document.getElementById('tratamiento_modificar').value = tratamiento;
            // Cambiamos la acción del formulario para que apunte a la ruta de la cita específica
            document.getElementById('formModificarCita').action = '<?php echo e(route('citas.update', '__ID__')); ?>'.replace('__ID__', id);
            // Mostramos el formulario de modificar cita
            document.getElementById('formularioModificarCita').classList.remove('hidden');
        }

        // Función para mostrar el formulario de agregar cita
        document.getElementById('mostrarFormulario').addEventListener('click', function() {
            document.getElementById('formularioCita').classList.remove('hidden');
        });
    });
</script>

<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto3\proyecto3\proyecto2\resources\views/historial.blade.php ENDPATH**/ ?>