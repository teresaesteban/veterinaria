<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Información de la mascota
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 text-black">
                    <?php if($mascota): ?>
                        <p><span>Nombre:</span> <?php echo e($mascota->nombre); ?></p>
                        <p><span>Tipo:</span> <?php echo e($mascota->tipo); ?></p>
                        <p><span>Edad:</span> <?php echo e($mascota->edad); ?></p>
                    <?php else: ?>
                        <p><span>No se encontró información de la mascota.</span></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Botón para agregar cita -->
    <div class="p-6 bg-gray-800 dark:bg-gray-700 border-b border-gray-600 dark:border-gray-600">
        <button id="mostrarFormulario" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded">
            <?php echo e(__('Agregar Cita')); ?>

        </button>
    </div>

    <!-- Contenedor del formulario de agregar cita -->
    <div id="formularioCita" class="hidden p-6 bg-gray-800 dark:bg-gray-700 border-b border-gray-600 dark:border-gray-600">
        <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Agregar Cita')); ?></h3>
        <form action="<?php echo e(route('citas.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="fecha" class="block text-sm font-medium text-gray-300"><?php echo e(__('Fecha de la Cita:')); ?></label>
                <input type="date" name="fecha" id="fecha" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black">
            </div>
            <div class="mb-4">
                <label for="motivo" class="block text-sm font-medium text-gray-300"><?php echo e(__('Motivo de la Cita:')); ?></label>
                <textarea name="motivo" id="motivo" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
            </div>
            <div class="mb-4">
                <label for="diagnostico" class="block text-sm font-medium text-gray-300"><?php echo e(__('Diagnóstico:')); ?></label>
                <textarea name="diagnostico" id="diagnostico" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
            </div>
            <div class="mb-4">
                <label for="tratamiento" class="block text-sm font-medium text-gray-300"><?php echo e(__('Tratamiento:')); ?></label>
                <textarea name="tratamiento" id="tratamiento" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
            </div>
            <div>
                <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:border-indigo-700 focus:ring focus:ring-indigo-300 transition">
                    <?php echo e(__('Guardar Cita')); ?>

                </button>
            </div>
        </form>
    </div>

    <!-- Contenedor de las citas -->
    <div class="p-6 bg-dark dark:bg-gray-700 border-b border-gray-600 dark:border-gray-600">
        <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Citas Registradas')); ?></h3>
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-600">
            <thead class="bg-gray-700 dark:bg-gray-600">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"><?php echo e(__('Fecha')); ?></th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"><?php echo e(__('Motivo de Cita')); ?></th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"><?php echo e(__('Diagnóstico')); ?></th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider"><?php echo e(__('Tratamiento')); ?></th>
                </tr>
            </thead>
            <tbody class="bg-gray-900 dark:bg-gray-800 text-white">
                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($cita->fecha); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($cita->motivo); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($cita->diagnostico); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?php echo e($cita->tratamiento); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Función para mostrar el formulario de agregar cita
        document.getElementById('mostrarFormulario').addEventListener('click', function() {
            document.getElementById('formularioCita').classList.remove('hidden');
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/mascota/show.blade.php ENDPATH**/ ?>