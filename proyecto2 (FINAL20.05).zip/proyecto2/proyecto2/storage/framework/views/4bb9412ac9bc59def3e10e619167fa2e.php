<?php if(session('language_switched')): ?>
    <p>You have switched to <span class="language">
    <?php if(session('language_switched') === 'en'): ?>
        <a href="<?php echo e(route('language.switch', 'es')); ?>">Spanish</a>
    <?php else: ?>
        <a href="<?php echo e(route('language.switch', 'en')); ?>">English</a>
    <?php endif; ?>
    </span></p>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/components/language-switch.blade.php ENDPATH**/ ?>