<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('CONSULTAS')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>New Age - Start Bootstrap Theme</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,600&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
      </head>
      <div class="py-12 bg-dark min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="content-section-heading text-center">
                        <h3 class="text-secondary mb-0">Últimas preguntas</h3>
                        <h2 class="mb-5 text-white">Listado consultas</h2>
                    </div>
                    <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full mb-8 rounded-lg p-6 shadow-md bg-custom-blue text-white">
                        <p class="mb-2"><strong>Nombre de la mascota:</strong> <?php echo e($consulta->nombre); ?></p>
                        <p class="mb-2"><strong>Especie:</strong> <?php echo e($consulta->especie); ?></p>
                        <p class="mb-2"><strong>Edad:</strong> <?php echo e($consulta->edad); ?></p>
                        <p class="mb-2"><strong>Síntomas:</strong> <?php echo e($consulta->sintomas); ?></p>
                        <p class="mb-2"><strong>Comentarios adicionales:</strong> <?php echo e($consulta->comentarios); ?></p>
                        <?php if($consulta->respuesta): ?>
                        <p class="mb-2"><strong>Respuesta:</strong> <?php echo e($consulta->respuesta); ?></p>
                    <?php endif; ?>
                        <form action="<?php echo e(route('consultas.destroy', $consulta->id)); ?>" method="POST" class="text-right">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700 focus:outline-none">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                         <form action="<?php echo e(route('responder.consulta', $consulta->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="consulta_id" value="<?php echo e($consulta->id); ?>">

                    </form>
                    <?php if(auth()->user()->hasRole('employee')): ?>
                    <form action="<?php echo e(route('responder.consulta')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="consulta_id" value="<?php echo e($consulta->id); ?>">
                        <div class="form-group">
                            <label for="respuesta">Respuesta:</label>
                            <textarea class="form-control" id="respuesta" name="respuesta" rows="3"><?php echo e(auth()->user()->name); ?>:</textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Enviar Respuesta</button>
                    </form>
                    <?php endif; ?>
                </div>
                <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/consultas.blade.php ENDPATH**/ ?>