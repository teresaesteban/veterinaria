<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <span id="page-title">Información de la mascota</span>
        </h2>
     <?php $__env->endSlot(); ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
            <meta name="description" content="" />
            <meta name="author" content="" />
            <title>New Age - Start Bootstrap Theme</title>
            <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
            <!-- Bootstrap icons-->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
            <!-- Google fonts-->
            <link rel="preconnect" href="https://fonts.gstatic.com" />
            <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,600&amp;display=swap" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet" />
            <!-- Core theme CSS (includes Bootstrap)-->
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />

          </head>
        <div class="container px-5">
            <br>
            <!-- Selector de mascotas -->
            <div class="mb-5">
                <form action="<?php echo e(route('usuarios.seleccionar-mascota', ['usuario' => $usuario])); ?>" method="POST" id="formSeleccionarMascota">
                    <?php echo csrf_field(); ?>
                    <label for="mascota"><span id="select-pet">Seleccionar Mascota:</span></label>
                    <select name="mascota_id" id="mascota" class="text-black" onchange="this.form.submit()">
                        <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php if($m->id == $mascota->id): ?> selected <?php endif; ?>><?php echo e($m->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>

            <!-- Información de la mascota seleccionada -->
            <div class="row gx-5 justify-content-center mb-5">
                <div class="col-lg-6">
                    <div class="card shadow border-0 rounded-4 bg-gradient-primary-to-secondary">
                        <div class="card-body p-5">
                            <h2 class="text-white fw-bolder mb-4"><span id="pet-info">Información de la Mascota</span></h2>
                            <table class="table">
                                <tbody>
                                    <tr class="text-white">
                                        <th scope="row"><span id="name">Nombre</span></th>
                                        <td><?php echo e($mascota->nombre); ?></td>
                                    </tr>
                                    <tr class="text-white">
                                        <th scope="row"><span id="age">Edad</span></th>
                                        <td><?php echo e($mascota->edad); ?></td>
                                    </tr>
                                    <tr class="text-white">
                                        <th scope="row"><span id="type">Tipo</span></th>
                                        <td><?php echo e($mascota->tipo); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        <div class="row gx-5 justify-content-center">
            <div class="col-lg-11 col-xl-9 col-xxl-8">
                <!-- Experience Section-->
                <section>
                    <?php if(auth()->user()->hasRole('employee')): ?>
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h2 class="text-white fw-bolder mb-0"><span id="history">Historial</span></h2>
                        <button id="mostrarFormulario" class="btn bg-gradient-primary-to-secondary text-white px-4 py-3">
                            <span id="add-appointment"><?php echo e(__('Agregar Cita')); ?></span>
                        </button>
                    </div>
                    <?php endif; ?>
                    <div id="formularioCita" class="hidden p-6 bg-gray-800 dark:bg-gray-700 border-b border-gray-600 dark:border-gray-600">
                        <section class="py-5">
                            <div class="container px-5">
                                <!-- Contact form-->
                                <div class="rounded-4 py-5 px-4 px-md-5">
                                    <div class="text-center mb-5">
                                        <h1 class="fw-bolder"><span id="addd-appointment">Agregar cita</span></h1>
                                        <p class="lead fw-normal text-muted mb-0"><span id="explain-reason">Explica detenidamente el motivo de la Cita</span></p>
                                    </div>

                                    <h3 class="text-lg font-semibold mb-4 text-white" id="adddd-appointment"><?php echo e(__('Agregar Cita')); ?></h3>

                                    <form action="<?php echo e(route('citas.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="mb-4">
                                            <label for="fecha" class="block text-sm font-medium text-gray-300" id="date"><?php echo e(__('Fecha de la Cita:')); ?></label>
                                            <input type="date" name="fecha" id="fecha" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black" required>
                                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-4">
                                            <label for="motivo" class="block text-sm font-medium text-gray-300"><?php echo e(__('Motivo de la Cita:')); ?></label>
                                            <textarea name="motivo" id="motivo" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black" required></textarea>
                                            <?php $__errorArgs = ['motivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-4">
                                            <label for="diagnostico" class="block text-sm font-medium text-gray-300"><?php echo e(__('Diagnóstico:')); ?></label>
                                            <textarea name="diagnostico" id="diagnostico" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black" required></textarea>
                                            <?php $__errorArgs = ['diagnostico'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-4">
                                            <label for="tratamiento" class="block text-sm font-medium text-gray-300"><?php echo e(__('Tratamiento:')); ?></label>
                                            <textarea name="tratamiento" id="tratamiento" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black" required></textarea>
                                            <?php $__errorArgs = ['tratamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p class="text-red-500 text-xs italic"><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Campo oculto para el ID de la mascota -->
                                        <input type="hidden" name="mascota_id" value="<?php echo e($mascota->id); ?>">

                                        <div>
                                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-nonefocus:border-indigo-700 focus:ring focus:ring-indigo-300 transition">
                                                <span id="save-appointment"><?php echo e(__('Guardar Cita')); ?></span>
                                            </button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Experience Cards for Citas-->
                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card shadow border-0 rounded-4 mb-5">
                            <div class="card-body p-5">
                                <div class="row align-items-center gx-5">
                                    <div class="col text-center text-lg-start mb-4 mb-lg-0">
                                        <div class=" p-4 rounded-4">
                                            <div class="text-primary fw-bolder mb-2"><?php echo e($cita->fecha); ?></div>
                                            <div class="small text-black"><span id="pet-name">Nombre de la mascota:</span> <?php echo e($cita->mascota->nombre); ?></div>
                                            <div class="small text-muted"><span id="pet-type">Tipo de mascota:</span> <?php echo e($cita->mascota->tipo); ?></div>
                                            <div class="small text-muted"><span id="appointment-reason">Motivo de la Cita:</span> <?php echo e($cita->motivo); ?></div>
                                            <div class="small text-muted"><span id="diagnosis">Diagnóstico:</span> <?php echo e($cita->diagnostico); ?></div>
                                            <div class="small text-muted"><span id="treatment">Tratamiento:</span> <?php echo e($cita->tratamiento); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            </div>
        </div>
    </div>

    <!-- Incluye el footer -->
    <?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Función para mostrar el formulario de agregar cita
            document.getElementById('mostrarFormulario').addEventListener('click', function() {
                document.getElementById('formularioCita').classList.remove('hidden');
            });
        });

        function translatePage(language) {
          const translations = {
            en: {
              'page-title': 'Pet Information',
              'select-pet': 'Select Pet:',
              'pet-info': 'Pet Information',
              'name': 'Name',
              'age': 'Age',
              'type': 'Type',
              'history': 'History',
              'add-appointment': 'Add Appointment',
              'addd-appointment': 'Add Appointment',
              'adddd-appointment': 'Add Appointment',
              'explain-reason': 'Explain the reason for the appointment',
              'save-appointment': 'Save Appointment',
              'pet-name': 'Pet Name:',
              'pet-type': 'Pet Type:',
              'appointment-reason': 'Appointment Reason:',
              'diagnosis': 'Diagnosis:',
              'treatment': 'Treatment:',
              "footer-copyright": "© 2024 Vet Clinic. All rights reserved.",
                "footer-contact": "CONTACT US",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
                "Inicio":"<?php echo e(__('HOME')); ?>",
                "Calendario":"<?php echo e(__('CALENDAR')); ?>",
                "Historial":"<?php echo e(__('HISTORY')); ?>",
                "Consultas":"<?php echo e(__('CONSULTS')); ?>",
                "Gestion":"<?php echo e(__('EMPLOYEES')); ?>",
                "Soporte":"<?php echo e(__('SUPPORT')); ?>",
                "Quelepasa":"<?php echo e(__('WHAT´S WRONG WITH MY PET')); ?>",
                "idioma":"Language",
            },
            es: {
              'page-title': 'Información de la mascota',
              'select-pet': 'Seleccionar Mascota:',
              'pet-info': 'Información de la Mascota',
              'name': 'Nombre',
              'age': 'Edad',
              'type': 'Tipo',
              'history': 'Historial',
              'add-appointment': 'Agregar Cita',
              'addd-appointment': 'Agregar Cita',
              'adddd-appointment': 'Add Appointment',
              'explain-reason': 'Explica detenidamente el motivo de la Cita',
              'save-appointment': 'Guardar Cita',
              'pet-name': 'Nombre de la mascota:',
              'pet-type': 'Tipo de mascota:',
              'appointment-reason': 'Motivo de la Cita:',
              'diagnosis': 'Diagnóstico:',
              'treatment': 'Tratamiento:',
              "footer-copyright": "© 2024 Vet Clinic. Todos los derechos reservados.",
                "footer-contact": "CONTACTE CON NOSOTROS",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
                "Inicio": "<?php echo e(__('INICIO')); ?>",
        "Calendario": "<?php echo e(__('CALENDARIO')); ?>",
        "Historial": "<?php echo e(__('HISTORIAL')); ?>",
        "Consultas": "<?php echo e(__('CONSULTAS')); ?>",
        "Gestion": "<?php echo e(__('GESTION DE EMPLEADOS')); ?>",
        "Soporte": "<?php echo e(__('SOPORTE')); ?>",
        "Quelepasa": "<?php echo e(__('¿QUE LE PASA A MI MASCOTA')); ?>",
        "idioma": "Idioma",
            }
          };

          // Actualizar el texto en la página según el idioma seleccionado
          Object.keys(translations[language]).forEach(key => {
            const element = document.getElementById(key);
            if (element) {
              element.textContent = translations[language][key];
            }
          });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/mascota/show.blade.php ENDPATH**/ ?>