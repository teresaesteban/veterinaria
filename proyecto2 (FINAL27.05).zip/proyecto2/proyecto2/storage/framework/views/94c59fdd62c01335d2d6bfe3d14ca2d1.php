<link href="css/styles.css" rel="stylesheet" /><div class="black"><div class="content">
    <div class="container">
        <div class="content-text">
            <p class="titulo" id="clinic-title">CUIDA A TUS MASCOTAS CON NOSOTROS</p>
            <p class="text-white" id="clinic-subtitle">Mejorando vidas, Aquí mismo</p>
            <button class="btn bg-gradient-primary-to-secondary text-white">  <?php if(Route::has('login')): ?>
                <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white">Inicio</a>
                    <?php else: ?>
                        <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500 text-white" id="register">Registrar</a>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?></button>
        </div>
    </div>
    <img src="<?php echo e(asset('images/portada.png')); ?>" alt="Veterinary Physician Preparing Hypodermic Needle Injection Sedative for Cat" class="content-image">

</div>

</div>
<script>
    function translatePage(language) {
        const translations = {
            en: {
                "home": "Home",
                "login": "Login",
                "clinic-title": "CARE FOR YOUR PETS WITH US",
                "clinic-subtitle": "Better lives, here",
                "register": "Register",
                "footer-copyright": "© 2024 Vet Clinic. All rights reserved.",
                "footer-contact": "CONTACT US",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
                "Inicio":"<?php echo e(__('HOME')); ?>",
                "Calendario":"<?php echo e(__('CALENDAR')); ?>",
                "Historial":"<?php echo e(__('HISTORY')); ?>",
                "Consultas":"<?php echo e(__('CONSULTS')); ?>",
                "Gestion":"<?php echo e(__('EMPLOYEES')); ?>",
                "Soporte":"<?php echo e(__('SUPPORT')); ?>",
                "Quelepasa":"<?php echo e(__('WHAT´S WRONG WITH MY PET')); ?>",
                "idioma":"Language",
            },
            es: {
                "home": "Inicio",
                "login": "Iniciar sesión",
                "clinic-title": "CUIDA A TUS MASCOTAS CON NOSOTROS",
                "clinic-subtitle": "Mejorando vidas, Aquí mismo",
                "register": "Registrarse",
                "footer-copyright": "© 2024 Vet Clinic. Todos los derechos reservados.",
                "footer-contact": "CONTACTE CON NOSOTROS",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
                "Inicio": "<?php echo e(__('INICIO')); ?>",
        "Calendario": "<?php echo e(__('CALENDARIO')); ?>",
        "Historial": "<?php echo e(__('HISTORIAL')); ?>",
        "Consultas": "<?php echo e(__('CONSULTAS')); ?>",
        "Gestion": "<?php echo e(__('GESTION DE EMPLEADOS')); ?>",
        "Soporte": "<?php echo e(__('SOPORTE')); ?>",
        "Quelepasa": "<?php echo e(__('¿QUE LE PASA A MI MASCOTA')); ?>",
        "idioma": "Idioma",
            }
        };

        // Actualizar el texto en la página según el idioma seleccionado
        Object.keys(translations[language]).forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                element.textContent = translations[language][key];
            }
        });
    }
</script><?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/registro/contenido.blade.php ENDPATH**/ ?>