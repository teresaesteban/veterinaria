<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 id="header-title" class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            CONSULTAS
        </h2>
     <?php $__env->endSlot(); ?>
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>New Age - Start Bootstrap Theme</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,600&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
      </head>
    <div class="py-12 bg-dark min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="content-section-heading text-center">
                        <h3 id="subheader-title" class="text-muted mb-0 fs-5">Últimas preguntas</h3>
                        <h2 id="header-main-title" class="mb-5 text-white fs-1">Listado consultas</h2>
                    </div>

                    <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full mb-8 rounded-lg p-6 shadow-md bg-custom-blue text-white">
                        <p class="mb-2"><strong id="pet-name-label">Nombre del usuario:</strong><?php echo e($consulta->user->name); ?></p>
                        <p class="mb-2"><strong id="pet-name-label">Nombre de la mascota:</strong> <?php echo e($consulta->nombre); ?></p>
                        <p class="mb-2"><strong id="species-label">Especie:</strong> <?php echo e($consulta->especie); ?></p>
                        <p class="mb-2"><strong id="age-label">Edad:</strong> <?php echo e($consulta->edad); ?></p>
                        <p class="mb-2"><strong id="symptoms-label">Síntomas:</strong> <?php echo e($consulta->sintomas); ?></p>
                        <p class="mb-2"><strong id="additional-comments-label">Comentarios adicionales:</strong> <?php echo e($consulta->comentarios); ?></p>
                        <?php if(!empty($consulta->imagen)): ?>
    <p class="mb-2">
        <strong id="imagen">
            <img src="<?php echo e(url('images/veterinaria/' . $consulta->imagen)); ?>" alt="Imagen de la consulta">
        </strong>
    </p>
<?php endif; ?>
                        <?php if($consulta->respuesta): ?>
                        <p class="mb-2"><strong id="response-label">Respuesta:</strong> <?php echo e($consulta->respuesta); ?></p>
                        <?php endif; ?>
                        <?php if(auth()->user()->id == $consulta->user_id): ?>
                        <form action="<?php echo e(route('consultas.destroy', $consulta->id)); ?>" method="POST" class="text-right">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" id="delete-btn">
                                Eliminar
                            </button>
                        </form>
                        <?php endif; ?>
                        <?php if(auth()->user()->hasRole('employee')): ?>
                        <form action="<?php echo e(route('responder.consulta', $consulta->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="consulta_id" value="<?php echo e($consulta->id); ?>">
                            <div class="form-group">
                                <label for="respuesta" id="response-label">Respuesta:</label>
                                <textarea class="form-control" id="response-placeholder" name="respuesta" rows="3"><?php echo e(auth()->user()->name); ?>:</textarea>
                            </div>
                            <br>
                            <button type="submit" class="btn bg-white text-black" id="send-response-btn">Enviar Respuesta</button>
                        </form>
                        <?php endif; ?>
                    </div>
                    <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- JavaScript para cambio de idioma -->
    <script>
        function translatePage(language) {
            const translations = {
                'es': {
                    'header-title': 'CONSULTAS',
                    'subheader-title': 'Últimas preguntas',
                    'header-main-title': 'Listado consultas',
                    'pet-name-label': 'Nombre de la mascota:',
                    'species-label': 'Especie:',
                    'age-label': 'Edad:',
                    'symptoms-label': 'Síntomas:',
                    'additional-comments-label': 'Comentarios adicionales:',
                    'response-label': 'Respuesta:',
                    'response-placeholder': 'Escribe tu respuesta aquí...',
                    'send-response-btn': 'Enviar Respuesta',
                    'delete-btn': 'Eliminar',
                    "footer-copyright": "© 2024 Vet Clinic. Todos los derechos reservados.",
                "footer-contact": "CONTACTE CON NOSOTROS",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
                "Inicio": "<?php echo e(__('INICIO')); ?>",
        "Calendario": "<?php echo e(__('CALENDARIO')); ?>",
        "Historial": "<?php echo e(__('HISTORIAL')); ?>",
        "Consultas": "<?php echo e(__('CONSULTAS')); ?>",
        "Gestion": "<?php echo e(__('GESTION DE EMPLEADOS')); ?>",
        "Soporte": "<?php echo e(__('SOPORTE')); ?>",
        "Quelepasa": "<?php echo e(__('¿QUE LE PASA A MI MASCOTA')); ?>",
        "idioma": "Idioma",
                },
                'en': {
                    'header-title': 'INQUIRIES',
                    'subheader-title': 'Latest Questions',
                    'header-main-title': 'Inquiry List',
                    'pet-name-label': 'Pet Name:',
                    'species-label': 'Species:',
                    'age-label': 'Age:',
                    'symptoms-label': 'Symptoms:',
                    'additional-comments-label': 'Additional Comments:',
                    'response-label': 'Response:',
                    'response-placeholder': 'Write your response here...',
                    'send-response-btn': 'Send Response',
                    'delete-btn': 'Delete',
                    "footer-copyright": "© 2024 Vet Clinic. All rights reserved.",
                "footer-contact": "CONTACT US",
                "footer-address": "C. de Jarque de Moncayo, 10, 50012 Zaragoza",
                "footer-phone": "976 30 08 04",
                "footer-email": "teresaestegraci@gmail.com",
        "Inicio":"<?php echo e(__('HOME')); ?>",
                "Calendario":"<?php echo e(__('CALENDAR')); ?>",
                "Historial":"<?php echo e(__('HISTORY')); ?>",
                "Consultas":"<?php echo e(__('CONSULTS')); ?>",
                "Gestion":"<?php echo e(__('EMPLOYEES')); ?>",
                "Soporte":"<?php echo e(__('SUPPORT')); ?>",
                "Quelepasa":"<?php echo e(__('WHAT´S WRONG WITH MY PET')); ?>",
                "idioma":"Language",
                }
            };
            // Actualizar el texto en la página según el idioma seleccionado
            Object.keys(translations[language]).forEach(key => {
                const element = document.getElementById(key);
                if (element) {
                    element.textContent = translations[language][key];
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/consultas.blade.php ENDPATH**/ ?>