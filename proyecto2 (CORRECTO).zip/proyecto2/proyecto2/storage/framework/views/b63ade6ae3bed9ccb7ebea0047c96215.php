<form action="<?php echo e(route('language.switch')); ?>" method="POST" class="inline-block">
    <?php echo csrf_field(); ?>
    <select name="language" onchange="this.form.submit()" class="p-2 rounded bg-gray-100">
        <option value="en" <?php echo e(app()->getLocale() == 'en' ? 'selected' : ''); ?>>English</option>
        <option value="es" <?php echo e(app()->getLocale() == 'es' ? 'selected' : ''); ?>>Spanish</option>
    </select>
</form>
<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/language-switch.blade.php ENDPATH**/ ?>