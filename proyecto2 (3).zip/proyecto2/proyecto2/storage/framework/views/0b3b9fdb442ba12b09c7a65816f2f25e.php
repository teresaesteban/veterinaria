<!-- resources/views/mascota/agregada.blade.php -->

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Mascota Agregada')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 text-black">
                    <p>Mascota agregada correctamente para el usuario <?php echo e($usuario->name); ?></p>

                    <!-- Formulario para ingresar datos de la mascota -->
                    <form action="<?php echo e(route('mascota.guardar')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="usuario_id" value="<?php echo e($usuario->id); ?>">
                        <div class="mt-4">
                            <label for="nombre">Nombre de la mascota:</label>
                            <input type="text" name="nombre" id="nombre" class="form-input block w-full mt-1">
                        </div>
                        <div class="mt-4">
                            <label for="tipo">Tipo de mascota:</label>
                            <input type="text" name="tipo" id="tipo" class="form-input block w-full mt-1">
                        </div>
                        <div class="mt-4">
                            <label for="edad">Edad de la mascota:</label>
                            <input type="number" name="edad" id="edad" class="form-input block w-full mt-1">
                        </div>
                        <div class="mt-4">
                            <button type="submit" class="bg-black hover:bg-gray-800 text-white font-bold py-2 px-4 rounded">Guardar Mascota</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/mascota/agregada.blade.php ENDPATH**/ ?>