<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            Información de la mascota
        </h2>
     <?php $__env->endSlot(); ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
            <meta name="description" content="" />
            <meta name="author" content="" />
            <title>New Age - Start Bootstrap Theme</title>
            <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
            <!-- Bootstrap icons-->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
            <!-- Google fonts-->
            <link rel="preconnect" href="https://fonts.gstatic.com" />
            <link href="https://fonts.googleapis.com/css2?family=Newsreader:ital,wght@0,600;1,600&amp;display=swap" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
            <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,400;1,400&amp;display=swap" rel="stylesheet" />
            <!-- Core theme CSS (includes Bootstrap)-->
            <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />

          </head>
          <div class="container px-5">
            <br>
            <!-- Selector de mascotas -->
            <div class="mb-5">
                <form action="<?php echo e(route('usuarios.seleccionar-mascota', ['usuario' => $usuario])); ?>" method="POST" id="formSeleccionarMascota">
                    <?php echo csrf_field(); ?>
                    <label for="mascota">Seleccionar Mascota:</label>
                    <select name="mascota_id" id="mascota" onchange="this.form.submit()">
                        <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php if($m->id == $mascota->id): ?> selected <?php endif; ?>><?php echo e($m->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>

            <!-- Información de la mascota seleccionada -->
            <div class="row gx-5 justify-content-center mb-5">
                <div class="col-lg-6">
                    <div class="card shadow border-0 rounded-4 bg-gradient-primary-to-secondary">
                        <div class="card-body p-5">
                            <h2 class="text-white fw-bolder mb-4">Información de la Mascota</h2>
                            <table class="table">
                                <tbody>
                                    <tr class="text-white">
                                        <th scope="row">Nombre</th>
                                        <td><?php echo e($mascota->nombre); ?></td>
                                    </tr>
                                    <tr class="text-white">
                                        <th scope="row">Edad</th>
                                        <td><?php echo e($mascota->edad); ?></td>
                                    </tr>
                                    <tr class="text-white">
                                        <th scope="row">Tipo</th>
                                        <td><?php echo e($mascota->tipo); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


        <div class="row gx-5 justify-content-center">
            <div class="col-lg-11 col-xl-9 col-xxl-8">
                <!-- Experience Section-->
                <section>
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h2 class="text-white fw-bolder mb-0">Historial</h2>
                        <button id="mostrarFormulario" class="btn btn-primary px-4 py-3">
                            <?php echo e(__('Agregar Cita')); ?>

                        </button>
                    </div>

                    <div id="formularioCita" class="hidden p-6 bg-gray-800 dark:bg-gray-700 border-b border-gray-600 dark:border-gray-600">
                        <section class="py-5">
                            <div class="container px-5">
                                <!-- Contact form-->
                                <div class="rounded-4 py-5 px-4 px-md-5">
                                    <div class="text-center mb-5">
                                        <h1 class="fw-bolder">Agregar cita</h1>
                                        <p class="lead fw-normal text-muted mb-0">Explica detenidamente el motivo de la Cita</p>
                                    </div>

                                    <h3 class="text-lg font-semibold mb-4 text-white"><?php echo e(__('Agregar Cita')); ?></h3>

                                    <form action="<?php echo e(route('citas.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="mb-4">
                                            <label for="fecha" class="block text-sm font-medium text-gray-300"><?php echo e(__('Fecha de la Cita:')); ?></label>
                                            <input type="date" name="fecha" id="fecha" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black">
                                        </div>

                                        <div class="mb-4">
                                            <label for="motivo" class="block text-sm font-medium text-gray-300"><?php echo e(__('Motivo de la Cita:')); ?></label>
                                            <textarea name="motivo" id="motivo" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
                                        </div>

                                        <div class="mb-4">
                                            <label for="diagnostico" class="block text-sm font-medium text-gray-300"><?php echo e(__('Diagnóstico:')); ?></label>
                                            <textarea name="diagnostico" id="diagnostico" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
                                        </div>

                                        <div class="mb-4">
                                            <label for="tratamiento" class="block text-sm font-medium text-gray-300"><?php echo e(__('Tratamiento:')); ?></label>
                                            <textarea name="tratamiento" id="tratamiento" rows="3" class="mt-1 focus:ring-indigo-500 focus:border-indigo-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md dark:bg-gray-800 text-black"></textarea>
                                        </div>

                                        <!-- Campo oculto para el ID de la mascota -->
                                        <input type="hidden" name="mascota_id" value="<?php echo e($mascota->id); ?>">

                                        <div>
                                            <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md font-semibold text-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:border-indigo-700 focus:ring focus:ring-indigo-300 transition">
                                                <?php echo e(__('Guardar Cita')); ?>

                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </section>
                    </div>

                    <!-- Experience Cards for Citas-->
                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card shadow border-0 rounded-4 mb-5">
                            <div class="card-body p-5">
                                <div class="row align-items-center gx-5">
                                    <div class="col text-center text-lg-start mb-4 mb-lg-0">
                                        <div class=" p-4 rounded-4">
                                            <div class="text-primary fw-bolder mb-2"><?php echo e($cita->fecha); ?></div>
                                            <div class="small text-black">Nombre de la mascota: <?php echo e($cita->mascota->nombre); ?></div>
                                            <div class="small text-muted">Tipo de mascota: <?php echo e($cita->mascota->tipo); ?></div>
                                            <div class="small text-muted">Motivo de la Cita: <?php echo e($cita->motivo); ?></div>
                                            <div class="small text-muted">Diagnóstico: <?php echo e($cita->diagnostico); ?></div>
                                            <div class="small text-muted">Tratamiento: <?php echo e($cita->tratamiento); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </section>
            </div>
        </div>
    </div>

    <!-- Incluye el footer -->
    <?php echo $__env->make('registro.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Función para mostrar el formulario de agregar cita
            document.getElementById('mostrarFormulario').addEventListener('click', function() {
                document.getElementById('formularioCita').classList.remove('hidden');
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\xampp\dwes\laravel\veterinaria\proyecto2\proyecto2\resources\views/mascota/show.blade.php ENDPATH**/ ?>