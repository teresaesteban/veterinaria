
<img src="{{ asset('images/unnamed-removebg-preview (3).png') }}" alt="Logo" class="navbar-logo" style="max-height: 70px;">